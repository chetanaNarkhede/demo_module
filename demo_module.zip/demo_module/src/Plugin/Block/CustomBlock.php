<?php

namespace Drupal\demo_module\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Link;

/**
 * Provides a 'Custom' Block.
 *
 * @Block(
 *   id = "custom_block",
 *   admin_label = @Translation("Custom block"),
 * )
 */
class CustomBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $menu_name = 'main';
   /* $menu_tree = \Drupal::menuTree();
    $parameters = $menu_tree->getCurrentRouteMenuTreeParameters($menu_name);
    $parameters->setMinDepth(0);
    //Delete comments to have only enabled links
    //$parameters->onlyEnabledLinks();

    $tree = $menu_tree->load($menu_name, $parameters);
    $manipulators = array(
      array('callable' => 'menu.default_tree_manipulators:checkAccess'),
      array('callable' => 'menu.default_tree_manipulators:generateIndexAndSort'),
    );
    $tree = $menu_tree->transform($tree, $manipulators);

    $list = [];

    foreach ($tree as $item) {
      $title = $item->link->getTitle();
      $url = $item->link->getUrlObject();
      $list[] = Link::fromTextAndUrl($title, $url);
    }

    return array(
    '#theme' => 'item_list',
    '#items' => $list,
    );
    //return $output;*/

    $menu_tree_service = \Drupal::service('menu.link_tree');
    $menu_parameters = new \Drupal\Core\Menu\MenuTreeParameters();
$menu_parameters->setMaxDepth(1);
$tree = $menu_tree_service->load($menu_name, $menu_parameters);
$manipulators = array(
  array('callable' => 'menu.default_tree_manipulators:checkAccess'),
);
$tree = $menu_tree_service->transform($tree, $manipulators);
foreach ($tree as $item) {
  $title = $item->link->getTitle();
  $url = $item->link->getUrlObject();
  $list[] = Link::fromTextAndUrl($title, $url);
  sort($list);
}
return array(
  '#theme' => 'item_list',
  '#items' => $list,
  );
  return $output;
  }
}